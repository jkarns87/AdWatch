import type { Metadata } from "next";
import Link from "next/link";
import "./globals.css";

export const metadata: Metadata = {
  title: "AdWatch",
  description: "Competitive ad intelligence that watches the market for you.",
  icons: { icon: "/favicon.png", apple: "/apple-touch-icon.png" },
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body className="min-h-screen">
        <header className="border-b" style={{ borderColor: "var(--line)" }}>
          <div className="mx-auto max-w-6xl px-5 py-3 flex items-center gap-4">
            <Link href="/" className="flex items-center gap-2 font-semibold tracking-tight text-lg" style={{ color: "var(--text)" }}>
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img src="/mark.svg" alt="" width={26} height={26} style={{ borderRadius: 6 }} />
              <span>Ad<span style={{ color: "var(--accent)" }}>Watch</span></span>
            </Link>
            <span className="muted text-sm">competitor ads · keyword SERPs · demand — diffed, explained, alerted</span>
          </div>
        </header>
        <main className="mx-auto max-w-6xl px-5 py-6">{children}</main>
      </body>
    </html>
  );
}
